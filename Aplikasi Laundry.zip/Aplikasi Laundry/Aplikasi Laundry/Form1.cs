﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Aplikasi_Laundry
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            
        }
        private int harga()
        {
            int harga = 0;  

            if (comboBox1.Text == "CUCI")
            {
                harga = 4000;
            }
            else if (comboBox1.Text == "CUCI SETRIKA")
            {
                 harga = 5000;
            }
            return harga;
        }

            private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
              int hargaLaundry = harga();
            string berat = txtBerat.Text;
            //int harga = 4000;
            int total = int.Parse(berat) *  hargaLaundry;
            lblTotal.Text = "Total : " +total.ToString();

        }

        private void txtBayar_TextChanged(object sender, EventArgs e)
        {
            string berat = txtBerat.Text;
            int harga = 4000;
            int total = int.Parse(berat) * harga;
            lblTotal.Text = "Total : " + total.ToString();
            int bayar = int.Parse(txtBayar.Text);
            int tomtal = int.Parse(berat) * harga;
            int kembalian = bayar - tomtal;
            lblkembali.Text = kembalian.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            txtBayar.Clear();
            txtBerat.Clear();
            lblTotal.Text = "Total";
            lblkembali.Text =  "Kembali";
            comboBox1.SelectedIndex = -1;
        }
        
        

        private void txtBerat_TextChanged(object sender, EventArgs e)
        {
            comboBox1.Enabled = true;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            comboBox1.Enabled = false;
        }
    }
}
